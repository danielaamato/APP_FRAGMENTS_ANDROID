package com.androidprog.fragments;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

public class PokemonHolder extends RecyclerView.ViewHolder implements View.OnClickListener
{
    private Pokemon pokemon;
    private TextView tvNom;
    private TextView tvAvistament;
    private ImageView ivCapturat;
    private Activity activity;

    public PokemonHolder(LayoutInflater inflater, ViewGroup parent, Activity
            activity)
    {
        super(inflater.inflate(R.layout.list_item_pokemon, parent, false));
        tvNom = (TextView) itemView.findViewById(R.id.nom_pokemon);
        tvAvistament = (TextView)itemView.findViewById(R.id.avistament_pokemon);
        ivCapturat = (ImageView)itemView.findViewById(R.id.ivCapturat);
        this.activity = activity;
        itemView.setOnClickListener(this);
    }

    public void bind(Pokemon pokemon) {
        this.pokemon = pokemon;
        tvNom.setText(pokemon.getName());
        tvAvistament.setText(pokemon.getAvistament().toString());
        ivCapturat.setVisibility(pokemon.isCaptured() ? View.VISIBLE :
                View.GONE);
    }

    @Override
    public void onClick(View view)
    {
        Toast.makeText(activity,
                        pokemon.getName() + " apretat!", Toast.LENGTH_SHORT)
                .show();

        int id = pokemon.getId();

        onChangePage(view, id);
    }

    private void onChangePage(View view, int id)
    {
        Intent intent = new Intent(activity, DetailActivity.class);
        intent.putExtra("id", id);

        activity.startActivity(intent);
    }
}
