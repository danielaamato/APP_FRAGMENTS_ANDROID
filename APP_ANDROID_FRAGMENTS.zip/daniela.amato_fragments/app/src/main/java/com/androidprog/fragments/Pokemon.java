package com.androidprog.fragments;

public class Pokemon
{
    private String name;
    private String imageName;

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }


    public int getId() {
        return id;
    }

    private boolean captured;

    public void setId(int id)
    {
        this.id = id;
    }

    private int id;

    public String getAvistament() {
        return avistament;
    }

    public void setAvistament(String avistament) {
        this.avistament = avistament;
    }

    private String avistament;

    public Pokemon()
    {
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public boolean isCaptured()
    {
        return captured;
    }

    public void setCaptured(boolean captured)
    {
        this.captured = captured;
    }
}
