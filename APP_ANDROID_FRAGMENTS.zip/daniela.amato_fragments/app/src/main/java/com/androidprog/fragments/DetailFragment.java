package com.androidprog.fragments;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.UUID;

public class DetailFragment extends Fragment {
    private EditText editTextName;
    private EditText editTextData;
    private CheckBox checkBox;
    private Pokemon pokemon;
    private List<Pokemon> lPokemon;
    private ImageView imageView;
    private Button button;
    private Activity activity;
    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private static final int RESULT_OK = 1;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int objectID = (int)
                getArguments().getSerializable("ARGUMENT_OBJECT_ID");

        Salledex pokedex = Salledex.getInstance(getActivity());
        lPokemon = pokedex.getPokemons();
        pokemon = getPokemonById(objectID);
    }

    public Pokemon getPokemonById(int id) {
        for (Pokemon pokemon : lPokemon) {
            if (pokemon.getId() == id) {
                return pokemon;
            }
        }

        return null;
    }

    @SuppressLint({"ResourceType", "MissingInflatedId"})
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_salledex, container, false);

        editTextName = v.findViewById(R.id.editTextTextPersonName);
        editTextName.setText(pokemon.getName());

        editTextData = v.findViewById(R.id.editTextDate);
        editTextData.setText(pokemon.getAvistament());

        checkBox = v.findViewById(R.id.Capturat);
        checkBox.setChecked(pokemon.isCaptured());

        button = v.findViewById(R.id.button);

        imageView = v.findViewById(R.id.imageView);
        if (pokemon.getImageName() != null) {
            Bitmap imagen = recuperarImagen(pokemon.getImageName());
            imageView.setImageBitmap(imagen);
        }

        editTextName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // no se necesita implementar este método
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                pokemon.setName(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
                // no se necesita implementar este método
            }
        });

        editTextData.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after)
            {
                // no se necesita implementar este método
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count)
            {
                pokemon.setAvistament(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
                // no se necesita implementar este método
            }
        });

        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                pokemon.setCaptured(isChecked);
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("QueryPermissionsNeeded")
            @Override
            public void onClick(View v) {
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

                if (cameraIntent.resolveActivity(getActivity().getPackageManager()) != null) {
                    startActivityForResult(cameraIntent, REQUEST_IMAGE_CAPTURE);
                }

                if (ContextCompat.checkSelfPermission(getActivity(),
                        android.Manifest.permission.READ_EXTERNAL_STORAGE) !=
                        PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(getActivity(), new
                            String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE, android.Manifest.permission.WRITE_EXTERNAL_STORAGE},0);
                }

                // Actualizar la vista de la imagen al final del método onClick
                if (pokemon.getImageName() != null) {
                    Bitmap imagen = recuperarImagen(pokemon.getImageName());
                    imageView.setImageBitmap(imagen);
                }
            }
        });


        return v;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            imageView.setImageBitmap(imageBitmap);
            saveImageToExternalStorage(imageBitmap);
            pokemon.setImageName(String.valueOf(imageBitmap));
        }
    }


    private void saveImageToExternalStorage(Bitmap bitmap)
    {
        String fileName = pokemon.getImageName();
        File directory =
                getActivity().getApplicationContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File imageFile = new File(directory, fileName);

        try {
            OutputStream outputStream = new FileOutputStream(imageFile);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
            outputStream.flush();
            outputStream.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

        recuperarImagen(fileName);
    }

    private Bitmap recuperarImagen(String imageName) {
        File directory =
                getActivity().getApplicationContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File imageFile = new File(directory, imageName);

        Bitmap bitmap = null;

        if (imageFile.exists()) {
            bitmap = BitmapFactory.decodeFile(imageFile.getAbsolutePath());
        }

        return bitmap;
    }
}
