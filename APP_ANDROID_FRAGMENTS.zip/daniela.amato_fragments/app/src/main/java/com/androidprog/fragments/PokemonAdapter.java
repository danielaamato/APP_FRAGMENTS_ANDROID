package com.androidprog.fragments;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PokemonAdapter extends RecyclerView.Adapter<PokemonHolder>
{
    private List<Pokemon> lPokemons;
    private Activity activity;

    public PokemonAdapter(List<Pokemon> lPokemons, Activity activity)
    {
        this.lPokemons = lPokemons;
        this.activity = activity;
    }

    @NonNull
    @Override
    public PokemonHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        LayoutInflater layoutInflater = LayoutInflater.from(activity);
        return new PokemonHolder(layoutInflater, parent, activity);
    }

    @Override
    public void onBindViewHolder(PokemonHolder holder, int position)
    {
        Pokemon pokemon = lPokemons.get(position);
        holder.bind(pokemon);
    }

    @Override
    public int getItemCount()
    {
        return lPokemons.size();
    }
}
