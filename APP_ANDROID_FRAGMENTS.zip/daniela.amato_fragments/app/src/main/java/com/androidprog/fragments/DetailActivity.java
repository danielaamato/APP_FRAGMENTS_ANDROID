package com.androidprog.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

public class DetailActivity extends SingleFragmentActivity {

    @Override
    protected Fragment createFragment() {

        DetailFragment fragment = new DetailFragment();
        Bundle args = new Bundle();

        int pokemonId = getIntent().getIntExtra("id", 0);

        args.putSerializable("ARGUMENT_OBJECT_ID", pokemonId);
        fragment.setArguments(args);

        return fragment;
    }
}