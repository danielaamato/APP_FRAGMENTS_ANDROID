package com.androidprog.fragments;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Salledex {
    private static Salledex sPokedex;
    private List<Pokemon> lPokemon;

    public static Salledex getInstance(Context context)
    {
        if (sPokedex == null)
        {
            sPokedex = new Salledex(context);
        }

        return sPokedex;
    }

    public Salledex(Context context)
    {

        lPokemon = new ArrayList<>();

        for (int i = 0; i < 100; i++)
        {
            Pokemon pokemon = new Pokemon();
            pokemon.setId(i);
            pokemon.setName("Pokemon #" + i);
            pokemon.setCaptured(i % 2 == 0);
            pokemon.setAvistament("06/03/2023");
            lPokemon.add(pokemon);
        }
    }

    public List<Pokemon> getPokemons()
    {
        return lPokemon;
    }


}
