package com.androidprog.fragments;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;

import java.util.List;

public class PokedexFragment extends Fragment
{
    private RecyclerView pokedexRecyclerView;
    private PokemonAdapter adapter;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View v = inflater.inflate(R.layout.fragment_pokdex, container, false);
        pokedexRecyclerView = (RecyclerView) v.findViewById(R.id.pokedex_recycler);
        pokedexRecyclerView.setLayoutManager(new
                LinearLayoutManager(getActivity()));
        updateUI();
        return v;
    }

    private void updateUI() {
        Salledex pokedex = Salledex.getInstance(getActivity());
        List<Pokemon> lPokemon = pokedex.getPokemons();

        SharedPreferences prefs = getActivity().getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor prefsEditor = prefs.edit();

        Gson gson = new Gson();

        String json = gson.toJson(lPokemon);

        prefsEditor.putString("JsonPokemons", json);

        prefsEditor.apply();

        if (adapter == null) {
            adapter = new PokemonAdapter(lPokemon, getActivity());
            pokedexRecyclerView.setAdapter(adapter);
        } else {
            adapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onResume()
    {
        super.onResume();
        updateUI();
    }
}
