package com.androidprog.fragments;

import androidx.fragment.app.Fragment;

public class PokedexActivity extends SingleFragmentActivity
{

    @Override
    protected Fragment createFragment() {
        return new PokedexFragment();
    }
}
